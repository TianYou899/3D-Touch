//
//  TianYouNetCountManager.m
//  3D Touch
//
//  Created by TianYou on 16/5/13.
//  Copyright © 2016年 hiservice_tech. All rights reserved.
//

#import "TianYouNetCountManager.h"

@implementation TianYouNetCountManager
+ (TianYouNetCountManager *)sharedNetCountManager
{
    static TianYouNetCountManager * sharedAccountManagerInstance = nil;
    static dispatch_once_t predicate;
    dispatch_once(&predicate, ^{
        sharedAccountManagerInstance = [[TianYouNetCountManager alloc] init];
        sharedAccountManagerInstance.netWorkingCount = 0;
        sharedAccountManagerInstance.applicationShortcutItemTitle = @"TianYou";
        sharedAccountManagerInstance.hadAutoLogin = NO;
        sharedAccountManagerInstance.tokenLostedAlratCount = 0;
    });
    return sharedAccountManagerInstance;
}
@end
