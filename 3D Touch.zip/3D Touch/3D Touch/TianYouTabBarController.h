//
//  TianYouTabBarController.h
//  3D Touch
//
//  Created by TianYou on 16/5/13.
//  Copyright © 2016年 hiservice_tech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TianYouTabBarController : UITabBarController

@end
