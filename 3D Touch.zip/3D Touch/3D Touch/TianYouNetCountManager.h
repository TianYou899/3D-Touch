//
//  TianYouNetCountManager.h
//  3D Touch
//
//  Created by TianYou on 16/5/13.
//  Copyright © 2016年 hiservice_tech. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TianYouNetCountManager : NSObject
@property(nonatomic,assign) NSInteger netWorkingCount;
@property(nonatomic,assign) NSInteger netGoodsListCount;
@property(nonatomic,assign) NSInteger tokenLostedAlratCount;
@property(nonatomic,assign) BOOL hadAutoLogin;
@property(nonatomic,assign) NSInteger noNetAlratCount;
@property(nonatomic,strong) NSString *  applicationShortcutItemTitle;

+(TianYouNetCountManager *)sharedNetCountManager;
@end
