//
//  AppDelegate.m
//  3D Touch
//
//  Created by TianYou on 16/5/13.
//  Copyright © 2016年 hiservice_tech. All rights reserved.
//

#import "AppDelegate.h"

#import "TianYouTabBarController.h"

#import "TianYouNetCountManager.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    //1.创建窗口
    self.window  = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    self.window.rootViewController = [[TianYouTabBarController alloc] init];
    [self.window makeKeyAndVisible];
    //3D Touch
    [self configShortCutItems];
    return YES;
}
//3D Touch
-(void)configShortCutItems
{
    //第一个去首页
    UIApplicationShortcutItem *item1 = [[UIApplicationShortcutItem alloc]initWithType:@"TianYou.Home" localizedTitle:@"首页" localizedSubtitle:@"副标题一" icon:[UIApplicationShortcutIcon iconWithType:UIApplicationShortcutIconTypeHome] userInfo:nil];
    //标题二去发现
    UIApplicationShortcutItem *item2 = [[UIApplicationShortcutItem alloc]initWithType:@"TianYou.Found" localizedTitle:@"发现" localizedSubtitle:@"副标题二" icon:[UIApplicationShortcutIcon iconWithType:UIApplicationShortcutIconTypeBookmark]userInfo:nil];
    //标题三去活动
    UIApplicationShortcutItem *item3 = [[UIApplicationShortcutItem alloc]initWithType:@"TianYou.Activity" localizedTitle:@"活动" localizedSubtitle:@"副标题三" icon:[UIApplicationShortcutIcon iconWithType:UIApplicationShortcutIconTypeConfirmation]userInfo:nil];
    //标题四
    UIApplicationShortcutItem *item4 = [[UIApplicationShortcutItem alloc]initWithType:@"TianYou.My" localizedTitle:@"我的" localizedSubtitle:@"副标题四" icon:[UIApplicationShortcutIcon iconWithType:UIApplicationShortcutIconTypeLove]userInfo:nil];
    // shortcutItems是一个数组
    [UIApplication sharedApplication].shortcutItems = @[item1,item2,item3,item4];
}
// iOS9 的 3D Touch
- (void)application:(UIApplication *)application performActionForShortcutItem:(UIApplicationShortcutItem *)shortcutItem completionHandler:(void(^)(BOOL succeeded))completionHandler
{
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 9.0 &&self.window.traitCollection.forceTouchCapability == UIForceTouchCapabilityAvailable)
    {
        NSLog(@"你的手机支持3D Touch!");
        TianYouNetCountManager * NetCountManager = [TianYouNetCountManager sharedNetCountManager];
        NetCountManager.applicationShortcutItemTitle = shortcutItem.type;
        //首页
        if([shortcutItem.type isEqualToString:@"TianYou.Home"])
        {
            [[NSNotificationCenter defaultCenter] postNotificationName:@"TianYou.Home" object:nil userInfo:nil];
        }
        //发现
        if([shortcutItem.type isEqualToString:@"TianYou.Found"])
        {
            [[NSNotificationCenter defaultCenter] postNotificationName:@"TianYou.Found" object:nil userInfo:nil];
        }
        //活动
        if([shortcutItem.type isEqualToString:@"TianYou.Activity"])
        {
            [[NSNotificationCenter defaultCenter] postNotificationName:@"TianYou.Activity" object:nil userInfo:nil];
        }
        //我的
        if([shortcutItem.type isEqualToString:@"TianYou.My"])
        {
            [[NSNotificationCenter defaultCenter] postNotificationName:@"TianYou.My" object:nil userInfo:nil];
        }
    }
    else
    {
        NSLog(@"你的手机暂不支持3D Touch!");
    }
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
