//
//  TianYouTabBarController.m
//  3D Touch
//
//  Created by TianYou on 16/5/13.
//  Copyright © 2016年 hiservice_tech. All rights reserved.
//

#import "TianYouTabBarController.h"
//首页
#import "HomePageViewController.h"
//发现
#import "FoundViewController.h"
//活动
#import "ActivityViewController.h"
//我的
#import "MyViewController.h"
//导航控制器
#import "TianYouNavigationController.h"
//
#import "TianYouNetCountManager.h"
//跳转
#import "FoundErViewController.h"

@interface TianYouTabBarController ()

@end

@implementation TianYouTabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor redColor];
    //添加子控制器
    [self addAllChildVcs];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationShortcutItemResponse) name:@"TianYou.Home" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationShortcutItemResponse) name:@"TianYou.Found" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationShortcutItemResponse) name:@"TianYou.Activity" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationShortcutItemResponse) name:@"TianYou.My" object:nil];
}
/**
 * 添加子控制器
 */
- (void)addAllChildVcs
{
    //添加首页控制器
    HomePageViewController * home = [[HomePageViewController alloc] init];
    [self addOneChildVc:home title:@"首页" imageName:@"tabbar_home" selectedImageName:nil];
    
    //添加发现控制器
    FoundViewController * found = [[FoundViewController alloc] init];
    [self addOneChildVc:found title:@"发现" imageName:@"tabbar_found" selectedImageName:nil];
    
    //添加活动控制器
    ActivityViewController * activity = [[ActivityViewController alloc] init];
    [self addOneChildVc:activity title:@"活动" imageName:@"tabbar_activity" selectedImageName:nil];
    
    //添加我的控制器
    MyViewController * my = [[MyViewController alloc] init];
    [self addOneChildVc:my title:@"我的" imageName:@"tabbar_my" selectedImageName:nil];
    
}
/*
 *  添加一个子控制器
 *  @param childVc              子控制器对象
 *  @param title                标题
 *  @param imageName            常态图片
 *  @param selectedIamgeName    选中状态图片
 */
- (void)addOneChildVc:(UIViewController *)childVc title:(NSString *)title imageName:(NSString *)imageName selectedImageName:(NSString *)selectedImageName
{
    if ([title isEqualToString:@""])
    {
        childVc.view.backgroundColor = [UIColor orangeColor];
        
    }
    //同时   设置 tabBarItem  和 navigationItem 标题
    childVc.title = title;
    //设置常态的图片
    if (![imageName isEqualToString:@""])
    {
        childVc.tabBarItem.image = [UIImage imageNamed:imageName];
    }
    //设置常态的字体字号 、颜色
    NSMutableDictionary * textAttrs = [NSMutableDictionary dictionary];
    textAttrs[NSForegroundColorAttributeName] = [UIColor grayColor];
    textAttrs[NSFontAttributeName] = [UIFont systemFontOfSize:10];
    [childVc.tabBarItem setTitleTextAttributes:textAttrs forState:UIControlStateNormal];
    
    //设置选中的字体颜色
    NSMutableDictionary * SelectTextAttrs = [NSMutableDictionary dictionary];
    SelectTextAttrs[NSForegroundColorAttributeName] = [UIColor orangeColor];
    [childVc.tabBarItem setTitleTextAttributes:SelectTextAttrs forState:UIControlStateSelected];
    
    //设置选中状态的图片
    UIImage * selectedImage;
    if (![selectedImageName isEqualToString:@""])
    {
        selectedImage =  [UIImage imageNamed:selectedImageName];
    }
    //在选中时，要想显示原图，就必须得告诉电脑，不要渲染
    childVc.tabBarItem.selectedImage = [selectedImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    self.tabBar.tintColor = [UIColor orangeColor];
    TianYouNavigationController * nav = [[TianYouNavigationController alloc] initWithRootViewController:childVc];
    
    //添加控制器到TabBar控制器
    [self addChildViewController:nav];
}
// 3DTouch
- (void)applicationShortcutItemResponse
{
    TianYouNetCountManager * sharedNetCountManager = [TianYouNetCountManager sharedNetCountManager];
    //首页
    if([sharedNetCountManager.applicationShortcutItemTitle isEqualToString:@"TianYou.Home"])
    {
        self.selectedIndex = 0;
        
    }
    //发现
    if([ sharedNetCountManager.applicationShortcutItemTitle isEqualToString:@"TianYou.Found"])
    {
        self.selectedIndex = 1;
        FoundErViewController * foundVC= [[FoundErViewController alloc] init];
        foundVC.navigationItem.title = @"天佑";
        [self.selectedViewController.childViewControllers[0].navigationController pushViewController:foundVC animated:YES];
    }
    //活动
    if([ sharedNetCountManager.applicationShortcutItemTitle isEqualToString:@"TianYou.Activity"])
    {
        self.selectedIndex = 2;
    }
    //我的 
    if([ sharedNetCountManager.applicationShortcutItemTitle isEqualToString:@"TianYou.My"])
    {
        self.selectedIndex = 3;
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
